#include <stdio.h>
#include "mysql.h"

#pragma comment(lib, "libmysql.lib")

const char* host = "localhost";
const char* user = "root";
const char* pw = "mdPwls93790!";
const char* db = "20191574";

int main(void) {

	MYSQL* connection = NULL;
	MYSQL conn;
	MYSQL_RES* sql_result;
	MYSQL_ROW sql_row;

	if (mysql_init(&conn) == NULL)
		printf("mysql_init() error!");

	connection = mysql_real_connect(&conn, host, user, pw, db, 3306, (const char*)NULL, 0);
	if (connection == NULL)
	{
		printf("%d ERROR : %s\n", mysql_errno(&conn), mysql_error(&conn));
		return 1;
	}

	else
	{
		printf("Connection Succeed\n");

		if (mysql_select_db(&conn, db))
		{
			printf("%d ERROR : %s\n", mysql_errno(&conn), mysql_error(&conn));
			return 1;
		}


		FILE* fp;
		char cmd[1001];
		const char* query;
		int state = 0;

		if ((fp = fopen("CREATE.txt", "r")) == NULL) printf("CREATE file open error\n");

		/* CREATE table */
		while (!feof(fp)) {
			fgets(cmd, 1000, fp);
			query = cmd;
			state = mysql_query(connection, query);
		}
		fclose(fp);

		if ((fp = fopen("INSERT.txt", "r")) == NULL) printf("INSERT file open error\n");
		
		/* INSERT record */
		while (!feof(fp)) {
			fgets(cmd, 1000, fp);
			query = cmd;
			state = mysql_query(connection, query);
		}
		fclose(fp);
		
		/* deal with Query */
		while (1) {
			printf("---------- SELECT QUERY TYPES ----------\n\n");
			printf("\t1. TYPE 1\n");
			printf("\t2. TYPE 2\n");
			printf("\t3. TYPE 3\n");
			printf("\t4. TYPE 4\n");
			printf("\t5. TYPE 5\n");
			printf("\t6. TYPE 6\n");
			printf("\t7. TYPE 7\n");
			printf("\t0. QUIT\n\n");
			printf("----------------------------------------\n\n");

			int op, subop;
			printf("SELECT OPTION : ");
			scanf("%d", &op);
			if (op == 0) break;
			printf("\n");

			const char *Q;
			char q[1000];
			
			// TYPE 1
			if (op == 1) {
				int k;
				char brand[20];
				printf("** Show the sales trends for a particular brand over the past k years **\n");
				printf("Which brand ? ");
				scanf("%s", brand);
				printf("Which k ? ");
				scanf("%d", &k);

				char date[15];
				int yy;
				yy = 2021 - k;
				sprintf(date, "'%d-01-01'", yy);

				printf("\n---------- Subtypes in TYPE 1 ----------\n");
				printf("\t1. TYPE 1-1\n");
				printf("\t2. TYPE 1-1-1\n\n");
				printf("SELECT SUBOPTION : ");
				scanf("%d", &subop);

				printf("\n");
				if (subop == 0) {
					printf("Exit TYPE 1\n\n");
					continue;
				}
				else if (subop == 1) {
					printf("** Then break these data out by gender of the buyer **\n\n");

					strcpy(q, "select model_name, size, body_type, door, price, count(model_name) as sold, gender from customers natural join own natural join vehicles natural join models where brand_name = '");
					strcat(q, brand);
					strcat(q, "' and (DATEDIFF(own_date, ");
					strcat(q, date);
					strcat(q, ") >= 0 ) group by model_name, gender order by gender");
					Q = q;

					state = mysql_query(connection, Q);
					printf("%15s%15s%15s%8s%15s%10s%20s\n\n", "model_name", "size", "body_type", "door", "price", "sold", "gender");
					if (state == 0) {
						sql_result = mysql_store_result(connection);
						while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
						{
							printf("%15s%15s%15s%8s%15s%10s%20s\n", sql_row[0], sql_row[1], sql_row[2], sql_row[3], sql_row[4], sql_row[5], sql_row[6]);
						}
						mysql_free_result(sql_result);
					}
				}
				else if (subop == 2) {
					printf("** Then by income range **\n\n");

					strcpy(q, "select model_name, size, body_type, door, price, annual_income from customers natural join own natural join vehicles natural join models where brand_name = '");
					strcat(q, brand);
					strcat(q, "' and (DATEDIFF(own_date, ");
					strcat(q, date);
					strcat(q, ") >= 0 ) order by annual_income");
					Q = q;

					state = mysql_query(connection, Q);
					printf("%15s%15s%15s%8s%15s%20s\n\n", "model_name", "size", "body_type", "door", "price", "annual_income");
					if (state == 0) {
						sql_result = mysql_store_result(connection);
						while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
						{
							printf("%15s%15s%15s%8s%15s%20s\n", sql_row[0], sql_row[1], sql_row[2], sql_row[3], sql_row[4], sql_row[5]);
						}
						mysql_free_result(sql_result);
					}
				}
				else {
					// for print error message and continue loop
					op = 8;
				}				
			}

			// TYPE 2
			else if (op == 2) {
				printf("** Show sales trends for various brands over the past k months **\n");
				int k;
				char date[5];
				printf("Which k ? ");
				scanf("%d", &k);
				sprintf(date, "%d", k);

				printf("\n---------- Subtypes in TYPE 2 ----------\n");
				printf("\t1. TYPE 2-1\n");
				printf("\t2. TYPE 2-1-1\n\n");

				printf("SELECT SUBOPTION : ");
				scanf("%d", &subop);

				printf("\n");
				if (subop == 0) {
					printf("Exit TYPE 2\n\n");
					continue;
				}
				else if (subop == 1) {
					printf("** Then break these data out by gender of the buyer **\n\n");

					strcpy(q, "select model_name, brand_name, size, body_type, door, price, count(model_name) as sold, gender from customers natural join own natural join vehicles natural join models where DATEDIFF(own_date, DATE_SUB(");
					strcat(q, "CURDATE(), INTERVAL ");
					strcat(q, date);
					strcat(q, " MONTH)) >= 0 group by model_name, gender order by gender");
					Q = q;

					state = mysql_query(connection, Q);
					printf("%15s%15s%15s%15s%8s%15s%10s%20s\n\n", "model_name", "brand_name", "size", "body_type", "door", "price", "sold", "gender");
					if (state == 0) {
						sql_result = mysql_store_result(connection);
						while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
						{
							printf("%15s%15s%15s%15s%8s%15s%10s%20s\n", sql_row[0], sql_row[1], sql_row[2], sql_row[3], sql_row[4], sql_row[5], sql_row[6], sql_row[7]);
						}
						mysql_free_result(sql_result);
					}
				}
				else if (subop == 2) {
					printf("** Then by income range **\n\n");

					strcpy(q, "select model_name, brand_name, size, body_type, door, price, annual_income from customers natural join own natural join vehicles natural join models where DATEDIFF(own_date, DATE_SUB(");
					strcat(q, "CURDATE(), INTERVAL ");
					strcat(q, date);
					strcat(q, " MONTH)) >= 0 order by annual_income");
					Q = q;

					state = mysql_query(connection, Q);
					printf("%15s%15s%15s%15s%8s%15s%20s\n\n", "model_name", "brand_name", "size", "body_type", "door", "price", "annual_income");
					if (state == 0) {
						sql_result = mysql_store_result(connection);
						while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
						{
							printf("%15s%15s%15s%15s%8s%15s%20s\n", sql_row[0], sql_row[1], sql_row[2], sql_row[3], sql_row[4], sql_row[5], sql_row[6]);
						}
						mysql_free_result(sql_result);
					}
				}
				else {
					// for print error message and continue loop
					op = 8;
				}
			}
			
			// TYPE 3
			else if (op == 3) {
				printf("** Find that transmissions made by supplier (company name) between two given dates are defective **\n");
				char sday[15], eday[15];
				char temps[15], tempd[15];
				char supplier[20];
				printf("Which supplier ? ");
				scanf("%s", supplier);
				printf("Start date (form : yyyy-mm-dd) ? ");
				scanf("%s", temps);
				sprintf(sday, "'%s'", temps);
				printf("End date (form : yyyy-mm-dd) ? ");
				scanf("%s", tempd);
				sprintf(eday, "'%s'", tempd);

				printf("\n---------- Subtypes in TYPE 3 ----------\n");
				printf("\t1. TYPE 3-1\n");
				printf("\t2. TYPE 3-2\n\n");

				printf("SELECT SUBOPTION : ");
				scanf("%d", &subop);
				printf("\n");

				if (subop == 0) {
					printf("Exit TYPE 3\n\n");
					continue;
				}
				else if (subop == 1) {
					printf("** Find the VIN of each car containing such a transmission and the customer to which it was sold **\n\n");

					strcpy(q, "with defect (VIN, model_name, customer_ID) as (select VIN, model_name, customer_ID from vehicles natural join own natural join options where option_type = 'transmission' and DATEDIFF(made_date, ");
					strcat(q, sday);
					strcat(q, ") >= 0 and DATEDIFF(");
					strcat(q, eday);
					strcat(q, ", made_date) >= 0) ");
					strcat(q, "select VIN, customer_ID from defect natural join mod_sup where supplier_name = '");
					strcat(q, supplier);
					strcat(q, "'");
					Q = q;

					state = mysql_query(connection, Q);
					printf("%10s%15s\n", "VIN", "customer_ID");
					if (state == 0) {
						sql_result = mysql_store_result(connection);
						while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
						{
							printf("%10s%15s\n", sql_row[0], sql_row[1]);
						}
						mysql_free_result(sql_result);
					}
				}
				else if (subop == 2) {
					printf("** Find the dealer who sold the VIN and transmission for each vehicles containing these transmissions **\n\n");
					strcpy(q, "with defect (VIN, dealer_ID, model_name) as (select VIN, dealer_ID, model_name from vehicles natural join own natural join options where option_type = 'transmission' and DATEDIFF(made_date, ");
					strcat(q, sday);
					strcat(q, ") >= 0 and DATEDIFF(");
					strcat(q, eday);
					strcat(q, ", made_date) >= 0) ");
					strcat(q, "select VIN, dealer_ID from defect natural join mod_sup where supplier_name = '");
					strcat(q, supplier);
					strcat(q, "'");
					Q = q;

					state = mysql_query(connection, Q);
					printf("%10s%15s\n", "VIN", "dealer_ID");
					if (state == 0) {
						sql_result = mysql_store_result(connection);
						while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
						{
							printf("%10s%15s\n", sql_row[0], sql_row[1]);
						}
						mysql_free_result(sql_result);
					}
				}
				else {
					// for print error message and continue loop
					op = 8;
				}

			}

			// TYPE 4
			else if (op == 4) {
				printf("---------- TYPE 4 ----------\n\n");
				printf("** Find the top k brands by dollar-amount sold by the year **\n");
				int k;
				char yyyy[5];
				printf("Which k ? ");
				scanf("%d", &k);
				printf("Which year (form : yyyy) ? ");
				scanf("%s", yyyy);

				strcpy(q, "select brand_name, sum(price) as dollar_amount_sold from vehicles natural join own natural join models where YEAR(own_date) = ");
				strcat(q, yyyy);
				strcat(q, " group by brand_name order by dollar_amount_sold desc");
				Q = q;
				int same = 1;	// ������ ��쿡 ���� ó��.
				char prev[20];	// ���� ��

				state = mysql_query(connection, Q);
				printf("%20s%20s\n", "brand_name", "dollar_amount_sold");
				if (state == 0) {
					sql_result = mysql_store_result(connection);
					for(int i=0; i<k;){
						if ((sql_row = mysql_fetch_row(sql_result)) == NULL) break;
						printf("%20s%20s\n", sql_row[0], sql_row[1]);
						if (i == 0) {
							i++;
							strcpy(prev, sql_row[1]);
						}
						else if (strcmp(prev, sql_row[1]) == 0) {	// ���� record�� ���� ����
							same++;
						}
						else {
							i += same;
							same = 1;
						}
					}
					mysql_free_result(sql_result);
				}
			}

			// TYPE 5
			else if (op == 5) {
				printf("---------- TYPE 5 ----------\n\n");
				printf("** Find the top k brands by unit sales by the year **\n");
				int k;
				char yyyy[5];
				printf("Which k ? ");
				scanf("%d", &k);
				printf("Which year (form : yyyy) ? ");
				scanf("%s", yyyy);

				strcpy(q, "select brand_name, count(VIN) as unit_sales from vehicles natural join own natural join models where YEAR(own_date) = ");
				strcat(q, yyyy);
				strcat(q, " group by brand_name order by unit_sales desc");
				Q = q;
				int same = 1;	// ������ ��쿡 ���� ó��.
				char prev[20];	// ���� ��

				state = mysql_query(connection, Q);
				printf("%20s%20s\n", "brand_name", "unit sales");
				if (state == 0) {
					sql_result = mysql_store_result(connection);
					for(int i=0; i<k;){
						if ((sql_row = mysql_fetch_row(sql_result)) == NULL) break;
						printf("%20s%20s\n", sql_row[0], sql_row[1]);
						if (i == 0) {
							i++;
							strcpy(prev, sql_row[1]);
						}
						else if (strcmp(prev, sql_row[1]) == 0) {	// ���� record�� ���� ����
							same++;
						}
						else {
							i += same;
							same = 1;
						}
					}
					mysql_free_result(sql_result);
				}
			}

			// TYPE 6
			else if (op == 6) {
				printf("---------- TYPE 6 ----------\n\n");
				printf("** In what month(s) do convertibles sell best ? **\n\n");

				strcpy(q, "select MONTH(own_date), count(VIN) as unit_sales from vehicles natural join own natural join models where body_type = 'convertible' group by MONTH(own_date) order by unit_sales desc");
				Q = q;
				char best[3];

				state = mysql_query(connection, Q);
				printf("Which month do convertible sell best : ");
				if (state == 0) {
					sql_result = mysql_store_result(connection);
					sql_row = mysql_fetch_row(sql_result);
					printf("%s", sql_row[0]);
					strcpy(best, sql_row[1]);	// best month�� unit_sales �� ���� for ���ÿ� best�� ��� ó��.
					while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
					{
						if (strcmp(sql_row[1], best) != 0) break;
						printf(", %s", sql_row[0]);
					}
					printf("\n");
					mysql_free_result(sql_result);
				}
			}

			// TYPE 7
			else if (op == 7) {
				printf("---------- TYPE 7 ----------\n\n");
				printf("** Find those dealers who keep a vehicle in inventory for the longest average time **\n\n");

				strcpy(q, "select dealer_ID, avg(DATEDIFF(CURDATE(), inv_date)) as avg_time from vehicles where is_sold = 0 group by dealer_ID order by avg_time desc");
				Q = q;

				state = mysql_query(connection, Q);
				printf("Which dealers keep a vehicle in inventory longest : ");
				char longest[20];
				if (state == 0) {
					sql_result = mysql_store_result(connection);
					sql_row = mysql_fetch_row(sql_result);
					printf("%s\n", sql_row[0]);
					strcpy(longest, sql_row[1]);
					while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
					{
						if (strcmp(sql_row[1], longest) != 0) break;
						printf(", %s", sql_row[0]);
					}
					printf("\n");
					mysql_free_result(sql_result);
				}
			}

			// error
			if (op < 0 || op > 7) {
				printf("\nOUT OF RANGE\n");
			}
			printf("\n\n");
		}

		if ((fp = fopen("DELETE_DROP.txt", "r")) == NULL) printf("DELETE_DROP file open error\n");

		/* DELETE record and DROP record */
		while (!feof(fp)) {
			fgets(cmd, 1000, fp);
			query = cmd;
			state = mysql_query(connection, query);
		}
		fclose(fp);

		mysql_close(connection);
	}
	return 0;
}